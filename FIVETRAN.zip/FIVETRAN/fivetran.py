#!/usr/bin/env python
# coding: utf-8
# Steps are followed for getting an actual output
1. strip function is added to remove unwanted spaces at the beginning and end of the string and splits with commas
2. nextLineIsATimestamp = True - Prints the timestamp at the end
3. next function creates the iterator (ts = next(formattedLine))
4. \n - removes the line break
# In[121]:


import os


nextLineIsATimestamp = False
newBlock = False
blocks = []
formattedLine = None
ts = None
index = 0

if os.path.exists("new_destination.csv"):
  os.remove("new_destination.csv")
else:
  print("The file does not exist")

writer = open("new_destination.csv", "a")

with open('source.log', 'r') as reader:

  for line in reader:
    index +=1
    block = []
    # strip is added to remove unwanted spaces at the beginning and end of the string
    formattedLine = line.strip().replace(" ", ',').split(",")    
    formattedLine = filter(None, formattedLine)
    
    if '----' in line:
      newBlock = True
            
    if newBlock is True:
      newBlock = False
    # prints the timestamp
      nextLineIsATimestamp = True
    elif nextLineIsATimestamp:
      # Prints the next line
      ts = next(formattedLine)
      # reset the state
      nextLineIsATimestamp = False
    else:
      block.extend(formattedLine)
      block.append(ts)
      writer.write(",".join(block)+"\n")
    
      formattedLine = None


# In[120]:


writer.close()

